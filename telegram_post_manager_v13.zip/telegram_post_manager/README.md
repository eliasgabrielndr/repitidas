# Gerenciador de Publicações para Telegram - Versão 2.0

## Introdução

Este aplicativo permite configurar e gerenciar publicações automáticas para grupos do Telegram através de múltiplos bots. Com ele, você pode:

- Cadastrar e gerenciar múltiplos bots do Telegram
- Configurar publicações com fotos ou vídeos
- Personalizar textos e botões para cada publicação
- Definir intervalos específicos para cada publicação
- Selecionar qual bot enviará cada publicação
- Enviar automaticamente para múltiplos grupos do Telegram
- Visualizar confirmação de envio para cada grupo
- Iniciar e parar bots individualmente ou todos de uma vez
- Gerenciar todas as configurações através de uma interface web amigável

## Requisitos

- Python 3.6 ou superior
- Conexão com a internet
- Um ou mais bots do Telegram com tokens válidos
- Grupos do Telegram onde os bots são administradores

## Instalação

1. Extraia todos os arquivos para uma pasta no seu computador
2. Abra um terminal ou prompt de comando na pasta extraída
3. Instale as dependências necessárias:

```
pip install -r requirements.txt
```

## Executando o Aplicativo

1. No terminal, navegue até a pasta do projeto e execute:

```
cd src
python main.py
```

2. Abra seu navegador e acesse:

```
http://localhost:5000
```

## Configuração de Bots

Antes de começar a criar publicações, você precisa configurar pelo menos um bot:

1. Clique em "Gerenciamento de Bots" no menu superior
2. Clique em "Novo Bot"
3. Preencha:
   - **Nome do Bot**: Um nome para identificar o bot no sistema
   - **Token do Bot**: Token obtido através do @BotFather
   - **Grupos Padrão**: IDs dos grupos onde o bot enviará mensagens por padrão
4. Clique em "Salvar Bot"

### Como obter o token do bot:
1. No Telegram, procure por @BotFather
2. Envie o comando `/newbot`
3. Siga as instruções para criar um novo bot
4. Copie o token fornecido e cole nas configurações

### Como obter o ID de um grupo:
1. Adicione seu bot ao grupo como administrador
2. Envie uma mensagem mencionando o bot
3. Acesse `https://api.telegram.org/bot[SEU_TOKEN]/getUpdates`
4. Procure pelo campo "chat" e copie o valor do "id" (geralmente um número negativo)

## Gerenciando Publicações

### Criar Nova Publicação

1. Na página principal, clique em "Nova Publicação"
2. Preencha os campos:
   - **Bot**: Selecione qual bot enviará esta publicação
   - **Tipo de Mídia**: Escolha entre foto ou vídeo
   - **URL da Mídia**: URL direta para o arquivo de mídia
   - **Legenda**: Texto que aparecerá junto com a mídia
   - **Texto do Botão**: Texto que aparecerá no botão (opcional)
   - **URL do Botão**: Link para onde o botão redirecionará (opcional)
   - **Intervalo**: Tempo em segundos entre os envios desta publicação
   - **IDs dos Grupos**: IDs dos grupos separados por vírgula (se deixar em branco, usará os grupos padrão do bot)
3. Clique em "Adicionar"

### Editar Publicação

1. Na página principal, localize a publicação desejada
2. Clique em "Editar"
3. Modifique os campos necessários
4. Clique em "Salvar Alterações"

### Excluir Publicação

1. Na página principal, localize a publicação desejada
2. Clique em "Excluir"
3. Confirme a exclusão

## Controle de Envio

Na parte superior da página principal, você encontrará o painel de controle de envio:

1. **Status dos Bots**: Mostra quais bots estão ativos ou inativos
2. **Iniciar Todos os Bots**: Inicia todos os bots cadastrados
3. **Parar Todos os Bots**: Para todos os bots em execução

Você também pode iniciar ou parar bots individualmente na página de gerenciamento de bots.

## Confirmação de Envio

Cada publicação mostra informações sobre o último envio:

1. **Último envio**: Data e hora do último envio
2. **Ver status de envio**: Clique para ver o status detalhado de envio para cada grupo
   - **Sucesso**: A publicação foi enviada com sucesso
   - **Falha**: Ocorreu um erro ao enviar a publicação (com detalhes do erro)

## Funcionamento do Sistema

- O sistema salva todas as configurações localmente em arquivos JSON
- As publicações são enviadas automaticamente nos intervalos definidos
- Cada publicação é enviada pelo bot selecionado
- Os bots precisam ser administradores nos grupos para enviar mensagens
- O sistema continuará enviando as publicações enquanto os bots estiverem ativos

## Solução de Problemas

- **Erro ao enviar para grupos**: Verifique se o bot é administrador nos grupos
- **Mídia não aparece**: Verifique se a URL da mídia está acessível e é direta para o arquivo
- **Bot não responde**: Verifique se o token está correto nas configurações
- **Publicações não são enviadas**: Verifique se o bot está ativo no painel de controle

## Observações Importantes

- O aplicativo deve permanecer em execução para que as publicações sejam enviadas
- Fechar o terminal ou o navegador não interrompe o envio das publicações
- Para interromper completamente, pressione CTRL+C no terminal onde o aplicativo está em execução
